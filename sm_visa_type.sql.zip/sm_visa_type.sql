-- phpMyAdmin SQL Dump
-- version 2.11.11.3
-- http://www.phpmyadmin.net
--
-- Host: 166.62.8.9
-- Generation Time: Oct 19, 2016 at 11:44 PM
-- Server version: 5.5.43
-- PHP Version: 5.1.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `devspm`
--

-- --------------------------------------------------------

--
-- Table structure for table `sm_visa_type`
--

CREATE TABLE `sm_visa_type` (
  `visa_type_id` int(250) NOT NULL AUTO_INCREMENT,
  `visa_type_name` varchar(250) NOT NULL,
  `visa_type_days` varchar(250) NOT NULL,
  `visa_type_status` varchar(250) NOT NULL DEFAULT '1',
  PRIMARY KEY (`visa_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `sm_visa_type`
--

INSERT INTO `sm_visa_type` VALUES(1, 'Working', '30', '1');
INSERT INTO `sm_visa_type` VALUES(2, 'Visiting', '20', '1');
INSERT INTO `sm_visa_type` VALUES(3, 'Bussiness', '40', '1');
INSERT INTO `sm_visa_type` VALUES(4, 'Family', '90', '1');
