-- phpMyAdmin SQL Dump
-- version 2.11.11.3
-- http://www.phpmyadmin.net
--
-- Host: 166.62.8.9
-- Generation Time: Oct 19, 2016 at 11:43 PM
-- Server version: 5.5.43
-- PHP Version: 5.1.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `devspm`
--

-- --------------------------------------------------------

--
-- Table structure for table `sm_visa_category`
--

CREATE TABLE `sm_visa_category` (
  `visa_category_id` int(250) NOT NULL AUTO_INCREMENT,
  `visa_category` varchar(250) NOT NULL,
  `visa_category_type` varchar(250) NOT NULL,
  `visa_category_status` int(250) NOT NULL DEFAULT '1',
  PRIMARY KEY (`visa_category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `sm_visa_category`
--

INSERT INTO `sm_visa_category` VALUES(1, 'New', '1', 1);
INSERT INTO `sm_visa_category` VALUES(2, 'Second renewal', '2', 1);
INSERT INTO `sm_visa_category` VALUES(3, 'Third renewal', '3', 1);
INSERT INTO `sm_visa_category` VALUES(4, 'New', '3', 1);
INSERT INTO `sm_visa_category` VALUES(5, 'New', '4', 1);
INSERT INTO `sm_visa_category` VALUES(6, 'Second renewal', '4', 1);
INSERT INTO `sm_visa_category` VALUES(7, 'Third renewal', '4', 1);
